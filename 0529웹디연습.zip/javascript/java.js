$('.main>li').mouseover(function(){
    $(this).find('.sub').stop().slideDown();
});
$('.main>li').mouseout(function(){
    $(this).find('.sub').stop().slideUp();
});

setInterval(function(){
    $('.slidelist').delay(3000);
    $('.slidelist').animate({marginLeft:-1200});
    $('.slidelist').delay(3000);
    $('.slidelist').animate({marginLeft:-2400});
    $('.slidelist').delay(3000);
    $('.slidelist').animate({marginLeft:0});
});

$('.tab>li>a').click(function(){
    $(this).parent().addClass('active')
    .siblings().removeClass('active');
    return false;
});