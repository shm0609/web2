$('.main>li').mouseover(function () {
    $(this).find('.sub').stop().slideDown();
});
$('.main>li').mouseout(function () {
    $(this).find('.sub').stop().slideUp();
});

setInterval(function () {
    $('.slidelist').delay(1000);
    $('.slidelist').animate({ marginTop: -300 });
    $('.slidelist').delay(2000);
    $('.slidelist').animate({ marginTop: -600 });
    $('.slidelist').delay(2000);
    $('.slidelist').animate({ marginTop: 0 });
    $('.slidelist').delay(2000);
});

$(function(){
    $('.tab>li>a').click(function(){
        $(this).parent().addClass("active")
            .siblings()
            .removeClass("active");
        return false;
    });
});

$(".notice li:first").click(function(){
    $("#layer").addClass("active");
});
$(".btn").click(function(){
    $("#layer").removeClass("active");
});