$('.main>li').mouseover(function(){
    // $(this).find('.sub').stop().slideDown(200)
    $('.sub').stop().slideDown(200)
});
$('.main>li').mouseout(function(){
    // $(this).find('.sub').stop().slideUp(200)
    $('.sub').stop().slideUp(200)
});

setInterval(function(){
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft:-1200});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft:-2400});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft:-3600});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: 0});
});