$('.main>li').mouseover()(function(){
    $(this).find('.sub').stop().slideDown()
});
$('.main>li').mouseout()(function(){
    $(this).find('.sub').stop().slideUp()
});