jQuery(document).ready(function(){
$('.main>li').mouseover(function(){
    $(this).find('.sub>li>a').stop().slideDown(500)
});
$('.main>li').mouseout(function(){
    $(this).find('.sub>li>a').stop().slideUp(500)
});
});