$('.main>li').mouseover(function(){
    $(this).find('.sub').stop().slideDown()
});
$('.main>li').mouseout(function(){
    $(this).find('.sub').stop().slideUp()
});

setInterval (function(){
    ('.slidelist').dealy(1000);
    ('.slidelist').animate({marginLeft:-800});
    ('.slidelist').dealy(2000);
    ('.slidelist').animate({marginLeft:-1600});
    ('.slidelist').dealy(2000);
    ('.slidelist').animate({marginLeft:0});
    ('.slidelist').dealy(2000);
});

$(".notice li:first").click(function(){
    $("#modal").addClass("active");
});

$(".btn").click(function(){
    $("#modal").removeClass("active");
});