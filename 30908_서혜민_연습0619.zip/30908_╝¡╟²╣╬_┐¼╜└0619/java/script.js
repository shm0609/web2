$('.main>li').mouseover(function(){
    $(this).find('.sub').stop().slideDown()
});
$('.main>li').mouseout(function(){
    $(this).find('.sub').stop().slideUp()
});

setInterval (function(){
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft : -800});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft : -1600});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft : 0});
    $('.slidelist').delay(2000);
});