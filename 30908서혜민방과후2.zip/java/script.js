$('.main>li').mouseout(function() {
    $(this).find('.sub').stop().slideUp(500)
});
$('.main>li').mouseover(function() {
    $(this).find('.sub').stop().slideDown(500)
});