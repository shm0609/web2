jQery(document).read(function(){
    $('.navi>li').mouseover(function(){
        $(this).find('.submenu').stop().sildeDown(500);
    }).mouseout(function(){
        $(this).find('submenu').stop().sildeUp(500);
    });

    setInterval(function(){
        $('.sildelist').delay(2000);
        $('.sildelist').animate({marginLeft:-800});
        $('.sildelist').delay(2000);
        $('.sildelist').animate({marginLeft:-1600});
        $('.sildelist').delay(2000);
        $('.sildelist').animate({marginLeft:0});
        $('.sildelist').delay(2000);
    })
});